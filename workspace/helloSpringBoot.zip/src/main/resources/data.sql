insert into customer(firstname, lastname) values ("alice", "kim")
insert into customer(firstname, lastname) values ("bob", "kim")
insert into customer(firstname, lastname) values ("charlie", "lee")